export const todayInfo = [
  { label: "Open today", value: "07:00 – 19:30", detail: "Monday to Saturday" },
  { label: "Find us", value: "28 Rue des Pyrénées", detail: "75020 Paris · near Père Lachaise" },
  { label: "Call us", value: "01 XX XX XX XX", detail: "For questions and special orders" },
] as const;
