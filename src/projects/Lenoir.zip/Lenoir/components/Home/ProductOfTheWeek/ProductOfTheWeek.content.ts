export const weeklyContent = {
  eyebrow: "PRODUCT OF THE WEEK",
  title: "Caramelised Apple Tart",
  description: "French apples, shortcrust pastry and salted butter caramel.",
  price: "€5.20",
  availability: "Available this week",
  imageAlt: "A caramelised apple tart prepared at Maison Lenoir.",
} as const;
