export const visitDetails={hours:{weekdays:"Mon–Sat · 07:00–19:30",sunday:"Sun · 07:00–13:30"},transport:"Métro 2 · Père Lachaise",phone:"01 XX XX XX XX"} as const;
